
package com.akjournal.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content; ArrayList<String> trades=new ArrayList<>();
    int purple=Color.rgb(124,77,255), bg=Color.rgb(11,13,18), card=Color.rgb(22,25,33);
    TextView title;
    public void onCreate(Bundle b){super.onCreate(b); showDashboard();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setPadding(18,14,18,14);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundColor(card);return b;}
    void base(String name){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        title=tv("A.K Journal  •  "+name,22); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(12,4,12,8);
        ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setBackgroundColor(Color.rgb(17,19,26));
        String[] ns={"Dashboard","Add Trade","Risk","History"};
        for(String n:ns){Button x=btn(n);nav.addView(x,new LinearLayout.LayoutParams(0,58,1));x.setOnClickListener(v->{if(n.equals("Dashboard"))showDashboard();else if(n.equals("Add Trade"))showAdd();else if(n.equals("Risk"))showRisk();else showHistory();});}
        root.addView(nav);setContentView(root);
    }
    TextView card(String s){TextView t=tv(s,17);t.setBackgroundColor(card);t.setPadding(20,20,20,20);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,8);content.addView(t,p);return t;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setInputType(2|8192);e.setPadding(16,10,16,10);content.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
    void showDashboard(){base("Dashboard"); card("📊  PERFORMANCE\n\nNet P/L     $0.00\nWin Rate    0%\nTrades      0\nProfit Factor  —\nMax Drawdown  $0.00"); card("🔥  A.K JOURNAL\nYour trading data stays on this device."); Button a=btn("＋  ADD YOUR FIRST TRADE");content.addView(a);a.setOnClickListener(v->showAdd());}
    void showAdd(){base("Add Trade");card("📝  NEW TRADE");
        EditText sym=input("Symbol (XAUUSD / NAS100 / EURUSD)"), side=input("Buy or Sell"), entry=input("Entry Price"), sl=input("Stop Loss"), tp=input("Take Profit"), lot=input("Lot Size"), pnl=input("Result P/L ($)");
        Button save=btn("SAVE TRADE");content.addView(save);save.setOnClickListener(v->{trades.add(sym.getText()+"  |  "+side.getText()+"  |  P/L $"+pnl.getText()+"  |  Entry "+entry.getText()+"  SL "+sl.getText()+"  TP "+tp.getText()+"  Lot "+lot.getText());Toast.makeText(this,"Trade saved ✓",Toast.LENGTH_SHORT).show();showHistory();});
    }
    double d(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}
    void showRisk(){base("Risk Calculator");card("🧮  RISK CALCULATOR");
        EditText bal=input("Account Balance ($)"), risk=input("Risk % (e.g. 1)"), entry=input("Entry Price"), sl=input("Stop Loss"), tp=input("Take Profit"), pipValue=input("Value per 1.00 lot per price unit ($)");
        Button calc=btn("CALCULATE RISK");content.addView(calc);TextView out=card("Enter values and calculate.");
        calc.setOnClickListener(v->{double b=d(bal),r=d(risk),en=d(entry),s=d(sl),t=d(tp),pv=d(pipValue);double money=b*r/100,dist=Math.abs(en-s),lots=pv>0?money/(dist*pv):0, reward=dist>0?Math.abs(t-en)/dist:0;out.setText("🧮  RESULT\n\nRisk Amount: $"+String.format("%.2f",money)+"\nSL Distance: "+String.format("%.5f",dist)+"\nSuggested Lot: "+String.format("%.2f",lots)+"\nPotential Loss: $"+String.format("%.2f",money)+"\nR:R: 1 : "+String.format("%.2f",reward));});
    }
    void showHistory(){base("Trade History");if(trades.size()==0)card("No trades yet.\n\nAdd a trade and it will appear here.");else for(String s:trades)card("📌 "+s);}
}
