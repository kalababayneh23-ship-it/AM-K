# A.K Journal
Android trading journal starter app.
Features: dashboard, add trades, local trade history, risk calculator and R:R calculation.
Open this project in Android Studio and Build > Build APK(s).
